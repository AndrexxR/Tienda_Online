package com.tienda.tienda_online;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
