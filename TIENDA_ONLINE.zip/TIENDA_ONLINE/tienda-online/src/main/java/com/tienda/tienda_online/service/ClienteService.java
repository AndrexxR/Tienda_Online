package com.tienda.tienda_online.service;

import com.tienda.tienda_online.model.Cliente;
import com.tienda.tienda_online.model.Direccion;
import com.tienda.tienda_online.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    // Crear cliente con dirección (como pide el taller)
    public Cliente crearClienteConDireccion(Cliente cliente, Direccion direccion) {
        cliente.setDireccion(direccion);
        return clienteRepository.save(cliente);
    }

    // Buscar todos los clientes
    public List<Cliente> obtenerTodosClientes() {
        return clienteRepository.findAll();
    }

    // Buscar cliente por ID
    public Optional<Cliente> obtenerClientePorId(Long id) {
        return clienteRepository.findById(id);
    }

    // Buscar cliente por email
    public Optional<Cliente> obtenerClientePorEmail(String email) {
        return clienteRepository.findByEmail(email);
    }

    // Buscar cliente con dirección
    public Optional<Cliente> obtenerClienteConDireccion(Long id) {
        return clienteRepository.findWithDireccionById(id);
    }

    // Actualizar cliente
    public Cliente actualizarCliente(Long id, Cliente clienteActualizado) {
        return clienteRepository.findById(id)
                .map(cliente -> {
                    cliente.setNombre(clienteActualizado.getNombre());
                    cliente.setEmail(clienteActualizado.getEmail());
                    return clienteRepository.save(cliente);
                })
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
    }

    // Eliminar cliente
    public void eliminarCliente(Long id) {
        clienteRepository.deleteById(id);
    }
}