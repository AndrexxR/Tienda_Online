package com.tienda.tienda_online.repository;

import com.tienda.tienda_online.model.Pedido;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    // Cargar pedido con items y productos (para evitar Lazy Loading)
    @EntityGraph(attributePaths = {"items", "items.producto"})
    Optional<Pedido> findWithItemsById(Long id);

    // Encontrar pedidos por cliente
    List<Pedido> findByClienteId(Long clienteId);

    // Total gastado por cliente (como pide el taller)
    @Query("SELECT SUM(p.total) FROM Pedido p WHERE p.cliente.id = :clienteId")
    Optional<Double> findTotalGastadoByClienteId(@Param("clienteId") Long clienteId);
}