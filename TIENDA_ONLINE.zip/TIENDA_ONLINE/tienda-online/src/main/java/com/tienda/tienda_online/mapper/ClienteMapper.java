package com.tienda.tienda_online.mapper;

import com.tienda.tienda_online.dto.ClienteDTO;
import com.tienda.tienda_online.dto.DireccionDTO;
import com.tienda.tienda_online.model.Cliente;
import com.tienda.tienda_online.model.Direccion;
import org.springframework.stereotype.Component;

@Component
public class ClienteMapper {

    public ClienteDTO toDTO(Cliente cliente) {
        if (cliente == null) {
            return null;
        }

        ClienteDTO dto = new ClienteDTO();
        dto.setId(cliente.getId());
        dto.setNombre(cliente.getNombre());
        dto.setEmail(cliente.getEmail());

        if (cliente.getDireccion() != null) {
            DireccionDTO direccionDTO = new DireccionDTO();
            direccionDTO.setId(cliente.getDireccion().getId());
            direccionDTO.setCalle(cliente.getDireccion().getCalle());
            direccionDTO.setCiudad(cliente.getDireccion().getCiudad());
            direccionDTO.setPais(cliente.getDireccion().getPais());
            direccionDTO.setZip(cliente.getDireccion().getZip());
            dto.setDireccion(direccionDTO);
        }

        return dto;
    }

    public Cliente toEntity(ClienteDTO clienteDTO) {
        if (clienteDTO == null) {
            return null;
        }

        Cliente cliente = new Cliente();
        cliente.setId(clienteDTO.getId());
        cliente.setNombre(clienteDTO.getNombre());
        cliente.setEmail(clienteDTO.getEmail());

        return cliente;
    }
}