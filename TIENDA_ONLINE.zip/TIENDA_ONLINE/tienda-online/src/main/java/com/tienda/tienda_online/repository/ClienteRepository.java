package com.tienda.tienda_online.repository;

import com.tienda.tienda_online.model.Cliente;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    // Buscar cliente por email
    Optional<Cliente> findByEmail(String email);

    // Cargar cliente con dirección (evita Lazy Loading)
    @EntityGraph(attributePaths = {"direccion"})
    Optional<Cliente> findWithDireccionById(Long id);
}