package com.tienda.tienda_online.service;

import com.tienda.tienda_online.model.Producto;
import com.tienda.tienda_online.model.Categoria;
import com.tienda.tienda_online.repository.ProductoRepository;
import com.tienda.tienda_online.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    // Crear producto
    public Producto crearProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    // Obtener todos los productos
    public List<Producto> obtenerTodosProductos() {
        return productoRepository.findAll();
    }

    // Obtener productos con paginación
    public Page<Producto> obtenerProductosPaginados(Pageable pageable) {
        return productoRepository.findAll(pageable);
    }

    // Buscar producto por ID
    public Optional<Producto> obtenerProductoPorId(Long id) {
        return productoRepository.findById(id);
    }

    // Buscar productos por categoría (como pide el taller)
    public List<Producto> obtenerProductosPorCategoria(String nombreCategoria) {
        return productoRepository.findByCategoriasNombre(nombreCategoria);
    }

    // Buscar productos por categoría con paginación
    public Page<Producto> obtenerProductosPorCategoria(String nombreCategoria, Pageable pageable) {
        return productoRepository.findByCategoriasNombre(nombreCategoria, pageable);
    }

    // Asignar categoría a producto (como pide el taller)
    public Producto asignarCategoriaAProducto(Long productoId, Long categoriaId) {
        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        Categoria categoria = categoriaRepository.findById(categoriaId)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));

        producto.addCategoria(categoria);
        return productoRepository.save(producto);
    }

    // Actualizar stock
    public Producto actualizarStock(Long id, Integer nuevoStock) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        producto.setStock(nuevoStock);
        return productoRepository.save(producto);
    }

    // Eliminar producto
    public void eliminarProducto(Long id) {
        productoRepository.deleteById(id);
    }
}