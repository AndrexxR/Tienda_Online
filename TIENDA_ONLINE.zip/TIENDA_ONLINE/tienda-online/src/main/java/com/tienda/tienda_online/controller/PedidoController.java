package com.tienda.tienda_online.controller;

import com.tienda.tienda_online.dto.PedidoDTO;
import com.tienda.tienda_online.mapper.PedidoMapper;
import com.tienda.tienda_online.model.ItemPedido;
import com.tienda.tienda_online.model.Pedido;
import com.tienda.tienda_online.service.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @Autowired
    private PedidoMapper pedidoMapper;

    // POST /clientes/{clienteId}/pedidos - como pide el taller
    @PostMapping("/clientes/{clienteId}")
    public ResponseEntity<PedidoDTO> crearPedido(
            @PathVariable Long clienteId,
            @RequestBody List<ItemPedido> items) {
        try {
            Pedido pedido = pedidoService.crearPedido(clienteId, items);
            return ResponseEntity.ok(pedidoMapper.toDTO(pedido));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // GET /pedidos/{id} - como pide el taller (DTO con items y totales)
    @GetMapping("/{id}")
    public ResponseEntity<PedidoDTO> obtenerPedidoPorId(@PathVariable Long id) {
        return pedidoService.obtenerPedidoPorId(id)
                .map(pedidoMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET /pedidos/cliente/{clienteId} - obtener pedidos por cliente
    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<List<PedidoDTO>> obtenerPedidosPorCliente(@PathVariable Long clienteId) {
        List<PedidoDTO> pedidos = pedidoService.obtenerPedidosPorCliente(clienteId)
                .stream()
                .map(pedidoMapper::toDTO)
                .collect(java.util.stream.Collectors.toList());
        return ResponseEntity.ok(pedidos);
    }

    // PUT /pedidos/{id}/estado?valor=ENVIADO - como pide el taller
    @PutMapping("/{id}/estado")
    public ResponseEntity<PedidoDTO> cambiarEstadoPedido(
            @PathVariable Long id,
            @RequestParam String valor) {
        try {
            Pedido pedido = pedidoService.cambiarEstadoPedido(id, valor.toUpperCase());
            return ResponseEntity.ok(pedidoMapper.toDTO(pedido));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}