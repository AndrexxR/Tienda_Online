package com.tienda.tienda_online.controller;

import com.tienda.tienda_online.dto.ProductoDTO;
import com.tienda.tienda_online.model.Producto;
import com.tienda.tienda_online.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    // POST /productos - crear producto
    @PostMapping
    public ResponseEntity<Producto> crearProducto(@RequestBody Producto producto) {
        Producto productoGuardado = productoService.crearProducto(producto);
        return ResponseEntity.ok(productoGuardado);
    }

    // GET /productos - obtener todos los productos (con paginación)
    @GetMapping
    public ResponseEntity<Page<Producto>> obtenerProductos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Producto> productos = productoService.obtenerProductosPaginados(pageable);
        return ResponseEntity.ok(productos);
    }

    // GET /productos?categoria=Backend&page=0&size=5 - como pide el taller
    @GetMapping("/buscar")
    public ResponseEntity<List<Producto>> obtenerProductosPorCategoria(
            @RequestParam String categoria,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Producto> productos = productoService.obtenerProductosPorCategoria(categoria, pageable);
        return ResponseEntity.ok(productos.getContent());
    }

    // GET /productos/{id} - obtener producto por ID
    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerProductoPorId(@PathVariable Long id) {
        return productoService.obtenerProductoPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST /productos/{id}/categorias - asignar categorías existentes
    @PostMapping("/{id}/categorias")
    public ResponseEntity<Producto> asignarCategoriaAProducto(
            @PathVariable Long id,
            @RequestParam Long categoriaId) {
        Producto producto = productoService.asignarCategoriaAProducto(id, categoriaId);
        return ResponseEntity.ok(producto);
    }
}