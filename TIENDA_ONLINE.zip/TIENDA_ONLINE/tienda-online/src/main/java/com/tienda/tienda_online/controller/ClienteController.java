package com.tienda.tienda_online.controller;

import com.tienda.tienda_online.dto.ClienteDTO;
import com.tienda.tienda_online.mapper.ClienteMapper;
import com.tienda.tienda_online.model.Cliente;
import com.tienda.tienda_online.model.Direccion;
import com.tienda.tienda_online.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ClienteMapper clienteMapper;

    // POST /clientes (crear cliente con dirección) - como pide el taller
    @PostMapping
    public ResponseEntity<ClienteDTO> crearCliente(@RequestBody Cliente cliente) {
        Cliente clienteGuardado = clienteService.crearClienteConDireccion(cliente, cliente.getDireccion());
        return ResponseEntity.ok(clienteMapper.toDTO(clienteGuardado));
    }

    // GET /clientes - obtener todos los clientes
    @GetMapping
    public ResponseEntity<List<ClienteDTO>> obtenerTodosClientes() {
        List<ClienteDTO> clientes = clienteService.obtenerTodosClientes()
                .stream()
                .map(clienteMapper::toDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(clientes);
    }

    // GET /clientes/{id} - obtener cliente por ID
    @GetMapping("/{id}")
    public ResponseEntity<ClienteDTO> obtenerClientePorId(@PathVariable Long id) {
        return clienteService.obtenerClienteConDireccion(id)
                .map(clienteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GET /clientes/email/{email} - buscar cliente por email
    @GetMapping("/email/{email}")
    public ResponseEntity<ClienteDTO> obtenerClientePorEmail(@PathVariable String email) {
        return clienteService.obtenerClientePorEmail(email)
                .map(clienteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}