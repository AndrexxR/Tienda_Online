package com.tienda.tienda_online.repository;

import com.tienda.tienda_online.model.Producto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    // Buscar productos por nombre de categoría (como pide el taller)
    List<Producto> findByCategoriasNombre(String nombre);

    // Buscar productos por categoría con paginación
    Page<Producto> findByCategoriasNombre(String nombre, Pageable pageable);

    // Buscar productos con stock bajo
    List<Producto> findByStockLessThan(Integer stock);

    // Búsqueda por nombre (like)
    @Query("SELECT p FROM Producto p WHERE p.nombre LIKE %:nombre%")
    List<Producto> findByNombreContaining(@Param("nombre") String nombre);
}