package com.tienda.tienda_online.service;

import com.tienda.tienda_online.model.*;
import com.tienda.tienda_online.repository.PedidoRepository;
import com.tienda.tienda_online.repository.ProductoRepository;
import com.tienda.tienda_online.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private ClienteRepository clienteRepository;

    // Crear pedido con validación de stock (como pide el taller)
    public Pedido crearPedido(Long clienteId, List<ItemPedido> items) {
        // Verificar que el cliente existe
        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        // Crear el pedido
        Pedido pedido = new Pedido(cliente);

        // Procesar cada item
        for (ItemPedido item : items) {
            // Validar stock (como pide el taller)
            Producto producto = productoRepository.findById(item.getProducto().getId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado: " + item.getProducto().getId()));

            if (producto.getStock() < item.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para: " + producto.getNombre() +
                        ". Stock disponible: " + producto.getStock());
            }

            // Decrementar stock (como pide el taller)
            producto.setStock(producto.getStock() - item.getCantidad());
            productoRepository.save(producto);

            // Configurar el item
            item.setPedido(pedido);
            item.setPrecioUnitario(producto.getPrecio());
            pedido.addItem(item);
        }

        // Calcular total (como pide el taller)
        pedido.calcularTotal();

        return pedidoRepository.save(pedido);
    }

    // Obtener pedido por ID
    public Optional<Pedido> obtenerPedidoPorId(Long id) {
        return pedidoRepository.findWithItemsById(id);
    }

    // Obtener pedidos por cliente
    public List<Pedido> obtenerPedidosPorCliente(Long clienteId) {
        return pedidoRepository.findByClienteId(clienteId);
    }

    // Cambiar estado del pedido (como pide el taller)
    public Pedido cambiarEstadoPedido(Long pedidoId, String nuevoEstado) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        // Si se cancela un pedido NUEVO, revertir stock
        if ("NUEVO".equals(pedido.getEstado()) && "CANCELADO".equals(nuevoEstado)) {
            revertirStock(pedido);
        }

        pedido.setEstado(nuevoEstado);
        return pedidoRepository.save(pedido);
    }

    // Revertir stock cuando se cancela un pedido
    private void revertirStock(Pedido pedido) {
        for (ItemPedido item : pedido.getItems()) {
            Producto producto = item.getProducto();
            producto.setStock(producto.getStock() + item.getCantidad());
            productoRepository.save(producto);
        }
    }

    // Calcular total gastado por cliente
    public Optional<Double> obtenerTotalGastadoPorCliente(Long clienteId) {
        return pedidoRepository.findTotalGastadoByClienteId(clienteId);
    }

    // Eliminar pedido
    public void eliminarPedido(Long id) {
        pedidoRepository.deleteById(id);
    }
}