package com.tienda.tienda_online.mapper;

import com.tienda.tienda_online.dto.PedidoDTO;
import com.tienda.tienda_online.dto.ItemPedidoDTO;
import com.tienda.tienda_online.model.Pedido;
import com.tienda.tienda_online.model.ItemPedido;
import org.springframework.stereotype.Component;
import java.util.stream.Collectors;

@Component
public class PedidoMapper {

    public PedidoDTO toDTO(Pedido pedido) {
        if (pedido == null) {
            return null;
        }

        PedidoDTO dto = new PedidoDTO();
        dto.setId(pedido.getId());
        dto.setFecha(pedido.getFecha());
        dto.setEstado(pedido.getEstado());
        dto.setTotal(pedido.getTotal());

        if (pedido.getCliente() != null) {
            dto.setClienteId(pedido.getCliente().getId());
            dto.setClienteNombre(pedido.getCliente().getNombre());
        }

        if (pedido.getItems() != null) {
            dto.setItems(pedido.getItems().stream()
                    .map(this::itemToDTO)
                    .collect(Collectors.toList()));
        }

        return dto;
    }

    private ItemPedidoDTO itemToDTO(ItemPedido item) {
        ItemPedidoDTO dto = new ItemPedidoDTO();
        dto.setId(item.getId());
        dto.setCantidad(item.getCantidad());
        dto.setPrecioUnitario(item.getPrecioUnitario());
        dto.setSubtotal(item.getSubtotal());

        if (item.getProducto() != null) {
            dto.setProductoId(item.getProducto().getId());
            dto.setProductoNombre(item.getProducto().getNombre());
        }

        return dto;
    }
}